# manager.py
import socket
import sys
from peer import Peer

# Globle data structure
peer_list = []

# Register function
def register(peer_name, ipv4addr, mport, pport):
    # Check if peer name is alphabetic and is less than 15
    if not peer_name.isalpha() or len(peer_name) > 15:
        return "FAILURE! Peer name must be an alphabetic string of length at most 15 characters."

    # Check if register is unique
    for obj in peer_list:
        # Check if mport and pport are unique
        if mport in obj.mport or pport in obj.pport:
            return "FAILURE! Ports already in use."
        
        # Check if peername is already registered
        if peer_name in obj.peername:
            return "FAILURE! Peer name already registered."

    # Register new peer
    status = "Free"
    peer_list.append(Peer(peer_name, ipv4addr, mport, pport, status))
    return "SUCCESS! Peer registered successfully."

# Execution of commands from peer (Switch Case)
def command_execution(command_name):
    command = command_name.split()
    
    if command[0] == "register":
        command_response = register(command[1], command[2], command[3], command[4])
    elif command[0] == "print_peer_list":
        command_response = print_peer_list()
    else:
        command_response = "FAILURE! Couldn't find command."
     
    return command_response

# Print Peer List Function
def print_peer_list():
    for obj in peer_list:
        print("\nPeer name: ", obj.peername, "\nIPv4 Address: ", obj.ipv4addr, "\nManager Port: ", obj.mport, 
              "\nPeer Port: ", obj.pport, "\nStatus: ", obj.status, "\n----------------------------")
        
    return "SUCCESS! List was printed"

# Main function
def main():
    # First argument for server port
    server_port = int(sys.argv[1])
    print("server: Port server is listening to: ", server_port)

    # Create socket
    server_sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

    # Bind socket to localhost with port argument
    server_sock.bind(('', server_port))

    # Infinite loop for receiving/sending messages 
    while True:
        message, client_address = server_sock.recvfrom(1024)
        server_sock.sendto(command_execution(message.decode()).encode(), client_address)

if __name__ == "__main__":
    main()